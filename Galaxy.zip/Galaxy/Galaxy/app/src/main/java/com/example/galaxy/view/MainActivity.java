package com.example.galaxy.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;

import com.example.galaxy.R;
import com.example.galaxy.adapter.ArticleAdapter;
//import com.example.galaxy.model.Article;
import com.example.galaxy.model.Article;
import com.example.galaxy.response.ArticleResponse;
import com.example.galaxy.viewmodel.ArticleViewModel;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    //private static final String TAG = MainActivity.class.getSimpleName();
    //private RecyclerView recycler_view;
    // private LinearLayoutManager layoutManager;
    //private ArrayList<Article> articleArrayList = new ArrayList<>();
    private ArticleViewModel articleViewModel;
    private ArticleAdapter adapter;
    private ArrayList<Article> articleArrayList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        adapter = new ArticleAdapter(MainActivity.this,articleArrayList);
        recyclerView.setAdapter(adapter);
        articleViewModel = ViewModelProviders.of(this).get(ArticleViewModel.class);

        //reference the viewmodel in the view and update recycle view adapter
        articleViewModel.getMilkyNewsResponseLiveData().observe(this, articleResponse -> {
            //update recycler view
            if(articleResponse!=null && articleResponse.getArticles()!=null){

                List<Article> articleList = articleResponse.getArticles();
                articleArrayList.addAll(articleList);

                //notify the adapter there is new data
                adapter.notifyDataSetChanged();
            }



        });
    }


}