package com.example.galaxy.viewmodel;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.galaxy.repository.ArticleRepository;
import com.example.galaxy.response.ArticleResponse;

/*Create ViewModel class and connect it to the repository
  This class manages the data for the main activity */
public class ArticleViewModel extends AndroidViewModel {

    //Create an obj of repository class
    private ArticleRepository articleRepository;
    private LiveData<ArticleResponse> articleResponseLiveData;

    //Constructor that take application as parameter
    public ArticleViewModel(@NonNull Application application){
        super(application);

        articleRepository = new ArticleRepository();
        //get or update LiveData from repository
        this.articleResponseLiveData = articleRepository.getMilkyNews();
    }
    public LiveData<ArticleResponse> getMilkyNewsResponseLiveData(){
        if(articleResponseLiveData==null){
            Log.i("ArticleViewModel","Live data is empty");
        }
        return articleResponseLiveData;
    }
}
