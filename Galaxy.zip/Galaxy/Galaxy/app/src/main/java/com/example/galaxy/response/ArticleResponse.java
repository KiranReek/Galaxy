package com.example.galaxy.response;

import com.example.galaxy.model.Article;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

//This class is used to create the Response Body for the getTopHeadLines() method ApiRequest.java
public class ArticleResponse {
    //Define a list that will contain the response data from the api call
    @SerializedName("items")
    @Expose
    private List<Article> articles;

    public List<Article> getArticles(){
        return articles;
    }

    @Override
    public String toString() {
        return "ArticleResponse{" +
                "articles=" + articles +
                '}';
    }
}
