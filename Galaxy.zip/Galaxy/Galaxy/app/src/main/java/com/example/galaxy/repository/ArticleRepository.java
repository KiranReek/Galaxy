package com.example.galaxy.repository;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.galaxy.response.ArticleResponse;
import com.example.galaxy.retrofit.ApiRequest;
import com.example.galaxy.retrofit.RetrofitRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

// This class combine view model and data sources.
public class ArticleRepository {
    private static final String TAG = ArticleRepository.class.getSimpleName();
    private final ApiRequest apiRequest;

    //create the api request
    public ArticleRepository() {
         apiRequest = RetrofitRequest.getRetrofitInstance().create(ApiRequest.class);
    }

    public LiveData<ArticleResponse> getMilkyNews(){
        final MutableLiveData<ArticleResponse> data = new MutableLiveData<>();

        //Ensure that the retrieval and processing of data is done in a background thread and not in the main UI thread
        //Android does not allow network processes to run on the main thread
        apiRequest.getTopHeadLines()
                .enqueue(new Callback<ArticleResponse>() {
                    @Override
                    public void onResponse(Call<ArticleResponse> call, Response<ArticleResponse> response) {
                        if(response.body()!=null){
                            Log.i("ArticleRepository","Response not null");
                            data.postValue(response.body());

                        }
                    }

                    @Override
                    public void onFailure(Call<ArticleResponse> call, Throwable t) {
                         Log.i("ArticleRepository","Response null");
                         data.postValue(null);
                    }
                });
        return data;
    }
}
