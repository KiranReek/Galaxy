package com.example.galaxy.variables;

public class constant {
    //Base url of the API
    public static final String BASE_URL = "https://images-api.nasa.gov/";

    //Nasa API KEY
    //public static final String API_KEY ="v1TAYfnhKcWB4NZ0b3ROUSaD7gHNYxEoYi6gIfDp";

}
