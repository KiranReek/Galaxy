package com.example.galaxy.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


//Model class for each API endpoint responses defined in the ApiRequest interface
public class Article {

    //Specify the name of the field in the JSON response
    @SerializedName("description")
    @Expose
    private String description;

    @SerializedName("title")
    @Expose
    private String title;

    @SerializedName("date_created")
    @Expose
    private String date_created;

   @SerializedName("center")
    @Expose
    private String center;


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    public String getCenter() {
        return center;
    }

    public void setCenter(String center) {
        this.center = center;
    }

    //Change json format to strings
    @Override
    public String toString() {
        return "Article{" +
                "description='" + description + '\'' +
                ", title='" + title + '\'' +
                ", date_created='" + date_created + '\'' +
                ", center='" + center + '\'' +
                '}';
    }
}

