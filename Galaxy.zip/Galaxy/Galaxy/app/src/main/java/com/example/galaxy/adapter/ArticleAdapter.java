package com.example.galaxy.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.galaxy.R;
import com.example.galaxy.model.Article;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.ViewHolder> {
    private final Context context;
    ArrayList<Article> articleArrayList;
   //private List<Article> articles  = new ArrayList<>();


    public ArticleAdapter(Context context,ArrayList<Article> articleArrayList) {
        this.context = context;
        this.articleArrayList = articleArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View articleView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.milky_item,parent,false);

        return new ViewHolder(articleView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
     Article currentArticle = articleArrayList.get(position);
     holder.title.setText(currentArticle.getTitle());
     holder.desc.setText(currentArticle.getDescription());
     Log.i("Title",currentArticle.getTitle());
     Log.i("desc",currentArticle.getDescription());
    }

    @Override
    public int getItemCount() {
        return articleArrayList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        //private final ImageView imgView;
        private TextView title;
        private TextView desc;

        public ViewHolder(@NonNull View itemView){
            super(itemView);

            title = itemView.findViewById(R.id.title);
            desc = itemView.findViewById(R.id.description);

        }

    }
}
