package com.example.galaxy.retrofit;

import static com.example.galaxy.variables.constant.API_KEY;

import com.example.galaxy.response.ArticleResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiRequest {

    //GET method calls getTopHeadlines()
   @GET("search?q=milky%20way&media_type=image&year_start=2017&year_end=2017")

   /*ArticleResponse is a Model POJO class for our response obj that's used to map the response
   parameter to their respective variables*/
    Call<ArticleResponse> getTopHeadLines();
}
