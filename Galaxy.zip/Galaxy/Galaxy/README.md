## Description
This is an Android app that explores the use of the NASA API. The app display data from Nasa's image and video library dated 2017. 
The app is built using 
 1)Java, 
 2)Android Studio
 3)MVVM Architecture
 4)NASA API
 5)Retrofit2 by Square for API processing.

## Status
Only the model package is incomplete.






